"""Machine Learning Time-Series Platform (cesium)

See http://cesium-ml.org for more information.
"""

from .version import version as __version__  # noqa: F401
